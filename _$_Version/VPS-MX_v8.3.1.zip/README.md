# VPS-MX By Kalix1 ( MOD NEW-ULTIMATE )
```
UPDATE 03/03/2021
```

![logo](https://github.com/Razhiel2019/VPS-MX/blob/main/Imagenes/NEW-ULTIMATE-VPS-MX-8.0.png)

**Manager Script**

## :heavy_exclamation_mark: Requerimientos

* Un sistema operativo basado en Linux (Ubuntu o Debian) 
* Recomendamos Ubuntu 16.04 Server x86_64 / 18.04 Server x86_64
* Se recomienda usar una distro nueva o formatiada

```
# SCRIPT VPS•MX ® Script Manager de VPS

ESTE ES UN SCRIPT PARA LA ADMINISTRACION DE CUENTAS DE TIPO:

-SSH
-SSL
-DROPBEAR
-OPENVPN
-SHADOWSOCK, SHADOWSOCK-liv, SHADOWSOCKR (PERSONAL)-V2RAY (PERSONAL)
-PANEL TROJAN
-IODINE
-BRAINFUCK PSIPHON PRO GO
-PROXYS (PYTHON-PUB,PYTHON-SEG,PYTHON-DIR,TCP OVER,SQUID)

MONITOREO DE:

-USUARIOS SSH/DROPBEAR/SSL/OPENVPN
-TIEMPO
-EXPIRACION
-MONITOR DE PROTOCOLOS

BOT MANAGER:

-CONTROLA EL USO DE TUS CUENTAS SSH DESDE UN BOT DE TELEGRAM
 (AGERAGR,ELIMINAR,RENOVAR,MIRAR CONECTADOS,SERVICOS DE TU VPS, IFO DE CUENTAS,ETC.)
-RECIBE NOTIFICACIONES CON BOT ESPECIAL
```

## :book: Installation

sudo apt update -y; apt upgrade -y; wget https://raw.githubusercontent.com/Razhiel2019/VPS-MX/main/instalscript.sh; chmod 777 instalscript.sh* && ./instalscript.sh*

```
VPS-MX Versao 8.3.1 (las dependencias faltantes se instalarán automáticamente)
```
-------------------------------------------------------------------------------

## :scroll: Registro de cambios

**VERSION: 8.3.1**

https://raw.githubusercontent.com/Razhiel2019/VPS-MX/main/Install/Vercion

## :octocat: Contribute

1. @Kalix1 - Developer of VPS-MX
2. @Rufu99 - Contributor
3. Team Casita-MX - Contributor
4. Team Illuminati - Contributor

-------------------------------------------------------------------------------
* Repositorios: https://github.com/VPS-MX
* Repositorios: https://github.com/rudi9999
* Repositorios: https://github.com/lacasitamx
-------------------------------------------------------------------------------

```
* SIN MINERIA! 
* SIN KEYS! 
* VERSION GRATUITA 
* SIN VIRUS TROJANO (BOTNET) 
* ARCHIVOS LIBERADOS (DECENCRIPTADOS)
```

```
☆ https://t.me/admmanagerfree ☆
```

**By: [  ⃘⃤꙰✰ ]**